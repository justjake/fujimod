/** The page's font rasterizer behind FocalUI's shared glyph provider. */
/** X70_GLYPHS_SCRATCH_BYTES: the fixed alpha buffer in glyph_raster.c. */
const GLYPH_SCRATCH_BYTES = 100 * 100;
export function glyphRecord(memory, pointer) {
    const view = new DataView(memory.buffer, pointer, 24);
    return {
        width: view.getUint32(0, true),
        height: view.getUint32(4, true),
        left: view.getInt32(8, true),
        top: view.getInt32(12, true),
        advance: view.getUint32(16, true),
        alpha: view.getUint32(20, true),
    };
}
export function glyphMetrics(memory, pointer, bitmap) {
    const view = new DataView(memory.buffer, pointer, 24);
    view.setUint32(0, bitmap.width, true);
    view.setUint32(4, bitmap.height, true);
    view.setInt32(8, bitmap.left, true);
    view.setInt32(12, bitmap.top, true);
    view.setUint32(16, bitmap.advance, true);
}
function fontWeight(family, size) {
    return `600 ${Math.max(1, size)}px ${family}`;
}
export function rasterizeGlyph(measure, glyph, page, family, code, size) {
    const character = String.fromCodePoint(code);
    measure.font = fontWeight(family, size);
    const metrics = measure.measureText(character);
    const advance = Math.max(1, Math.round(metrics.width));
    // The camera's atlas cell is the font's em box: its advance wide and its
    // size tall, with the glyph's origin at the cell's top left.
    const width = Math.min(page - 2, Math.max(1, advance));
    const height = Math.min(page - 2, Math.max(1, size));
    const ascent = metrics.fontBoundingBoxAscent || Math.round(size * 0.8);
    glyph.font = fontWeight(family, size);
    glyph.clearRect(0, 0, page, page);
    glyph.fillStyle = '#fff';
    glyph.fillText(character, 0, ascent);
    const pixels = glyph.getImageData(0, 0, width, height).data;
    const alpha = new Uint8Array(width * height);
    for (let index = 0; index < alpha.length; ++index)
        alpha[index] = pixels[index * 4 + 3];
    return { alpha, width, height, left: 0, top: 0, advance };
}
/** Install the C provider's page callback. */
export function installRasterizer(module, measure, glyph, page, family, changed) {
    const scope = globalThis;
    scope.focalWebRasterizeGlyph = (code, size, pointer) => {
        const record = glyphRecord(module.HEAPU8, pointer);
        const bitmap = rasterizeGlyph(measure, glyph, page, family, code, size);
        if (bitmap.alpha.length > GLYPH_SCRATCH_BYTES)
            return 1;
        if (bitmap.alpha.length)
            module.HEAPU8.set(bitmap.alpha, record.alpha);
        glyphMetrics(module.HEAPU8, pointer, bitmap);
        changed();
        return 0;
    };
}
