import { startFocalPage } from './focal-renderer.js';
const canvas = document.querySelector('#focal');
const status = document.querySelector('#status');
if (!canvas || !status)
    throw Error('The FocalUI page is missing its canvas or status element');
try {
    const loader = await import(new URL(import.meta.url.replace(/\.page\.js$/, '.wasm.js')).href);
    await startFocalPage(canvas, loader.default, status, {
        width: canvas.width,
        height: canvas.height,
    });
}
catch (error) {
    status.dataset.state = 'error';
    status.textContent = error instanceof Error ? error.message : String(error);
    console.error(error);
}
