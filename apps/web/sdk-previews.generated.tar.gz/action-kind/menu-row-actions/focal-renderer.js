/** Draw FocalUI's layer batches and provide browser-font glyphs to the toolkit. */
import { installRasterizer } from './web_glyphs.js';
const GLYPH_PAGE = 256;
const VECTOR_PAGE = 512;
const SHAPE_ATLAS = 128;
const VECTOR_TEXTURE = 1 + 8;
const CUSTOM_TEXTURE = 0xffff;
const VERTEX_SIZE = 12;
const SPAN_SIZE = 14;
const VERTEX_FLOATS = 8;
const VERTEX_STRIDE = VERTEX_FLOATS * 4;
const FONT_FAMILY = '"Source Sans 3", "Helvetica Neue", "Arial", sans-serif';
export async function startFocalPage(canvas, loader, status, options) {
    const module = await loader({
        locateFile: path => new URL(path, import.meta.url).href,
        noExitRuntime: true,
    });
    const web = new FocalWeb({ canvas, module, width: options.width, height: options.height });
    web.start();
    status.dataset.state = 'ready';
    return web;
}
export class FocalWeb {
    #canvas;
    #module;
    #gl;
    #glyphCanvas;
    #glyph;
    #measure;
    #textures = [];
    #uploaded = new Set();
    #program;
    #position;
    #texCoord;
    #color;
    #textureLocation;
    #pixelsLocation;
    #glyphDirty = false;
    #frame = 0;
    #pointerDown = false;
    width;
    height;
    constructor(options) {
        this.#canvas = options.canvas;
        this.#module = options.module;
        // Page compositing may replace the drawing buffer after the browser's
        // paint. Preserve it so screenshots and pixel checks see the frame FocalUI
        // submitted rather than the canvas's cleared back buffer.
        const gl = options.canvas.getContext('webgl', {
            alpha: false, antialias: false, preserveDrawingBuffer: true,
        });
        if (!gl)
            throw Error('WebGL is unavailable');
        this.#gl = gl;
        this.#glyphCanvas = document.createElement('canvas');
        this.#glyphCanvas.width = GLYPH_PAGE;
        this.#glyphCanvas.height = GLYPH_PAGE;
        const glyph = this.#glyphCanvas.getContext('2d', { willReadFrequently: true });
        const measure = document.createElement('canvas').getContext('2d');
        if (!glyph || !measure)
            throw Error('Canvas 2D is unavailable');
        this.#glyph = glyph;
        this.#measure = measure;
        this.width = options.width;
        this.height = options.height;
        options.canvas.width = this.width;
        options.canvas.height = this.height;
        this.#program = this.#createProgram();
        this.#position = gl.getAttribLocation(this.#program, 'position');
        this.#texCoord = gl.getAttribLocation(this.#program, 'texCoord');
        this.#color = gl.getAttribLocation(this.#program, 'color');
        if (this.#position < 0 || this.#texCoord < 0 || this.#color < 0)
            throw Error('WebGL vertex attributes are unavailable');
        const textureLocation = gl.getUniformLocation(this.#program, 'texture');
        const pixelsLocation = gl.getUniformLocation(this.#program, 'pixels');
        if (!textureLocation || !pixelsLocation)
            throw Error('WebGL uniforms are unavailable');
        this.#textureLocation = textureLocation;
        this.#pixelsLocation = pixelsLocation;
        this.#installInput(options);
    }
    start() {
        this.#installRasterizer();
        this.#module.ccall('focal_web_start', null, [], []);
        const width = this.#module.ccall('Focal_Web_width', 'number', [], []);
        const height = this.#module.ccall('Focal_Web_height', 'number', [], []);
        if (width !== this.width || height !== this.height)
            throw Error(`FocalUI initialized at ${width}x${height}, not ${this.width}x${this.height}`);
        this.#frame = requestAnimationFrame(this.#tick);
    }
    stop() {
        if (this.#frame)
            cancelAnimationFrame(this.#frame);
        this.#frame = 0;
    }
    #tick = () => {
        const now = performance.now();
        const result = this.#module.ccall('focal_web_frame', 'number', ['number'], [now]);
        if (result < 0)
            throw Error(`FocalUI frame failed: ${result}`);
        if (this.#glyphDirty) {
            this.#glyphDirty = false;
            for (let page = 1; page <= 8; ++page)
                this.#uploaded.delete(page);
        }
        this.#draw();
        this.#module.ccall('focal_web_presented', null, [], []);
        this.#frame = requestAnimationFrame(this.#tick);
    };
    #installInput(options) {
        const touch = (phase, x, y) => {
            this.#module.ccall('focal_web_touch', null, ['number', 'number', 'number', 'number'], [phase, x, y, performance.now()]);
        };
        const key = (kind, direction) => {
            this.#module.ccall('focal_web_key', null, ['number', 'number', 'number', 'number'], [kind, direction, 0, performance.now()]);
        };
        const point = (event) => {
            const box = options.canvas.getBoundingClientRect();
            return [
                (event.clientX - box.left) * this.width / box.width,
                (event.clientY - box.top) * this.height / box.height,
            ];
        };
        options.canvas.addEventListener('pointerdown', event => {
            options.canvas.setPointerCapture(event.pointerId);
            this.#pointerDown = true;
            touch(1, ...point(event));
        });
        options.canvas.addEventListener('pointermove', event => {
            if (this.#pointerDown)
                touch(2, ...point(event));
        });
        const end = (event) => {
            if (!this.#pointerDown)
                return;
            this.#pointerDown = false;
            touch(3, ...point(event));
        };
        options.canvas.addEventListener('pointerup', end);
        options.canvas.addEventListener('pointercancel', end);
        window.addEventListener('keydown', event => {
            const directions = {
                ArrowUp: 0, ArrowDown: 1, ArrowLeft: 2, ArrowRight: 3,
            };
            if (event.key in directions) {
                event.preventDefault();
                key(0, directions[event.key]);
            }
            else if (event.key === 'Enter' || event.key === ' ') {
                event.preventDefault();
                key(1, 0);
            }
            else if (event.key === 'Escape') {
                event.preventDefault();
                key(2, 0);
            }
        });
    }
    /** Install C's glyph rasterizer over the browser's font. */
    #installRasterizer() {
        installRasterizer(this.#module, this.#measure, this.#glyph, GLYPH_PAGE, FONT_FAMILY, () => {
            this.#glyphDirty = true;
        });
    }
    #createProgram() {
        const gl = this.#gl;
        const vertex = gl.createShader(gl.VERTEX_SHADER);
        const fragment = gl.createShader(gl.FRAGMENT_SHADER);
        const program = gl.createProgram();
        if (!vertex || !fragment || !program)
            throw Error('WebGL program allocation failed');
        gl.shaderSource(vertex, `
      attribute vec2 position;
      attribute vec2 texCoord;
      attribute vec4 color;
      varying vec2 uv;
      varying vec4 paint;
      uniform vec2 pixels;
      void main() {
        gl_Position = vec4(position.x / pixels.x * 2.0 - 1.0,
                           1.0 - position.y / pixels.y * 2.0, 0.0, 1.0);
        uv = texCoord;
        paint = color;
      }`);
        gl.shaderSource(fragment, `
      precision mediump float;
      uniform sampler2D texture;
      varying vec2 uv;
      varying vec4 paint;
      void main() {
        float coverage = texture2D(texture, uv).r;
        gl_FragColor = vec4(paint.rgb, paint.a * coverage);
      }`);
        gl.compileShader(vertex);
        gl.compileShader(fragment);
        if (!gl.getShaderParameter(vertex, gl.COMPILE_STATUS) ||
            !gl.getShaderParameter(fragment, gl.COMPILE_STATUS))
            throw Error(gl.getShaderInfoLog(vertex) || gl.getShaderInfoLog(fragment) ||
                'WebGL shader compilation failed');
        gl.attachShader(program, vertex);
        gl.attachShader(program, fragment);
        gl.linkProgram(program);
        if (!gl.getProgramParameter(program, gl.LINK_STATUS))
            throw Error(gl.getProgramInfoLog(program) || 'WebGL program link failed');
        return program;
    }
    #texture(index) {
        const existing = this.#textures[index];
        if (existing)
            return existing;
        const gl = this.#gl;
        const texture = gl.createTexture();
        if (!texture)
            throw Error('WebGL texture allocation failed');
        gl.bindTexture(gl.TEXTURE_2D, texture);
        const filter = index === 0 ? gl.LINEAR : gl.NEAREST;
        gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, filter);
        gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, filter);
        gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
        gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
        this.#textures[index] = texture;
        return texture;
    }
    #uploadTexture(index) {
        if (this.#uploaded.has(index))
            return;
        const gl = this.#gl;
        gl.bindTexture(gl.TEXTURE_2D, this.#texture(index));
        gl.pixelStorei(gl.UNPACK_ALIGNMENT, 1);
        if (index === 0) {
            const atlas = this.#module.ccall('Focal_Web_atlas', 'number', [], []);
            const data = this.#module.HEAPU8.subarray(atlas, atlas + SHAPE_ATLAS * SHAPE_ATLAS);
            gl.texImage2D(gl.TEXTURE_2D, 0, gl.LUMINANCE, SHAPE_ATLAS, SHAPE_ATLAS, 0, gl.LUMINANCE, gl.UNSIGNED_BYTE, data);
        }
        else if (index < VECTOR_TEXTURE) {
            const page = this.#module.ccall('Focal_Web_glyphPage', 'number', ['number'], [index - 1]);
            const data = this.#module.HEAPU8.subarray(page, page + GLYPH_PAGE * GLYPH_PAGE);
            gl.texImage2D(gl.TEXTURE_2D, 0, gl.LUMINANCE, GLYPH_PAGE, GLYPH_PAGE, 0, gl.LUMINANCE, gl.UNSIGNED_BYTE, data);
        }
        else {
            const page = this.#module.ccall('Focal_Web_vectorPage', 'number', ['number'], [index - VECTOR_TEXTURE]);
            const size = this.#module.ccall('Focal_Web_vectorPageSize', 'number', [], []);
            const data = this.#module.HEAPU8.subarray(page, page + size * size);
            gl.texImage2D(gl.TEXTURE_2D, 0, gl.LUMINANCE, size, size, 0, gl.LUMINANCE, gl.UNSIGNED_BYTE, data);
        }
        this.#uploaded.add(index);
    }
    #drawCustom(index) {
        const gl = this.#gl;
        // The Wasm callback draws synchronously and clips rectangles to its span.
        const previous = globalThis.focalWebFillRect;
        globalThis.focalWebFillRect = (x, y, width, height, rgb) => {
            gl.enable(gl.SCISSOR_TEST);
            gl.scissor(x, this.height - y - height, width, height);
            gl.clearColor(((rgb >>> 16) & 255) / 255, ((rgb >>> 8) & 255) / 255, (rgb & 255) / 255, 1);
            gl.clear(gl.COLOR_BUFFER_BIT);
        };
        try {
            this.#module.ccall('Focal_Web_drawCustom', null, ['number'], [index]);
        }
        finally {
            globalThis.focalWebFillRect = previous;
        }
    }
    #draw() {
        const gl = this.#gl;
        const vertices = this.#module.ccall('Focal_Web_vertices', 'number', [], []);
        const spans = this.#module.ccall('Focal_Web_spans', 'number', [], []);
        const spanCount = this.#module.ccall('Focal_Web_spanCount', 'number', [], []);
        gl.viewport(0, 0, this.width, this.height);
        gl.disable(gl.SCISSOR_TEST);
        gl.clearColor(20 / 255, 20 / 255, 20 / 255, 1);
        gl.clear(gl.COLOR_BUFFER_BIT);
        if (!spanCount)
            return;
        gl.useProgram(this.#program);
        gl.uniform2f(this.#pixelsLocation, this.width, this.height);
        gl.uniform1i(this.#textureLocation, 0);
        gl.enable(gl.BLEND);
        gl.blendEquation(gl.FUNC_ADD);
        gl.colorMask(true, true, true, true);
        gl.blendFuncSeparate(gl.SRC_ALPHA, gl.ONE_MINUS_SRC_ALPHA, gl.ONE, gl.ONE_MINUS_SRC_ALPHA);
        const quadCount = this.#module.ccall('Focal_Web_quadCount', 'number', [], []);
        const spanBytes = this.#module.HEAPU8.subarray(spans, spans + spanCount * SPAN_SIZE);
        const spanView = new DataView(spanBytes.buffer, spanBytes.byteOffset, spanBytes.byteLength);
        const vertexBytes = this.#module.HEAPU8.subarray(vertices, vertices + quadCount * 4 * VERTEX_SIZE);
        const view = new DataView(vertexBytes.buffer, vertexBytes.byteOffset, vertexBytes.byteLength);
        for (let spanIndex = 0; spanIndex < spanCount; ++spanIndex) {
            const offset = spanIndex * SPAN_SIZE;
            const first = spanView.getUint16(offset, true);
            const count = spanView.getUint16(offset + 2, true);
            const texture = spanView.getUint16(offset + 4, true);
            if (texture === CUSTOM_TEXTURE) {
                this.#drawCustom(first);
                continue;
            }
            if (texture >= VECTOR_TEXTURE + 3)
                continue;
            this.#uploadTexture(texture);
            gl.bindTexture(gl.TEXTURE_2D, this.#texture(texture));
            const clip = [spanView.getInt16(offset + 6, true), spanView.getInt16(offset + 8, true),
                spanView.getInt16(offset + 10, true), spanView.getInt16(offset + 12, true)];
            gl.enable(gl.SCISSOR_TEST);
            gl.scissor(clip[0], this.height - clip[3], clip[2] - clip[0], clip[3] - clip[1]);
            const data = new Float32Array(count * 6 * VERTEX_FLOATS);
            const order = [0, 1, 2, 0, 2, 3];
            let quadOutput = 0;
            for (let quad = first; quad < first + count; ++quad) {
                for (const corner of order) {
                    const base = (quad * 4 + corner) * VERTEX_SIZE;
                    const scale = texture === 0 ? SHAPE_ATLAS :
                        texture < VECTOR_TEXTURE ? GLYPH_PAGE : VECTOR_PAGE;
                    const outputBase = quadOutput * VERTEX_FLOATS;
                    data[outputBase] = view.getInt16(base, true);
                    data[outputBase + 1] = view.getInt16(base + 2, true);
                    data[outputBase + 2] = view.getInt16(base + 4, true) / scale;
                    data[outputBase + 3] = view.getInt16(base + 6, true) / scale;
                    data[outputBase + 4] = view.getUint8(base + 8) / 255;
                    data[outputBase + 5] = view.getUint8(base + 9) / 255;
                    data[outputBase + 6] = view.getUint8(base + 10) / 255;
                    data[outputBase + 7] = view.getUint8(base + 11) / 255;
                    ++quadOutput;
                }
            }
            const buffer = gl.createBuffer();
            gl.bindBuffer(gl.ARRAY_BUFFER, buffer);
            gl.bufferData(gl.ARRAY_BUFFER, data, gl.STREAM_DRAW);
            gl.enableVertexAttribArray(this.#position);
            gl.enableVertexAttribArray(this.#texCoord);
            gl.enableVertexAttribArray(this.#color);
            gl.vertexAttribPointer(this.#position, 2, gl.FLOAT, false, VERTEX_STRIDE, 0);
            gl.vertexAttribPointer(this.#texCoord, 2, gl.FLOAT, false, VERTEX_STRIDE, 8);
            gl.vertexAttribPointer(this.#color, 4, gl.FLOAT, false, VERTEX_STRIDE, 16);
            gl.drawArrays(gl.TRIANGLES, 0, count * 6);
            gl.deleteBuffer(buffer);
        }
        gl.disable(gl.SCISSOR_TEST);
    }
}
